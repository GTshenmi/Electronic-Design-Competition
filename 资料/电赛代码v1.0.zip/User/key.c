#include "key.h" 

u8 KEY1_Flag=0;
u8 KEY2_Flag=0;
u8 KEY3_Flag=0;
u8 KEY4_Flag=0;
u8 KEY5_Flag=0;
u8 KEY6_Flag=1;

u16 num=0;

static void Key_GPIO_Init(void)
{    	 
  GPIO_InitTypeDef  GPIO_InitStructure;

  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);//ʹ��GPIOFʱ��

  //GPIOF9,F10��ʼ������
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12| GPIO_Pin_13| GPIO_Pin_14| GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;//��ͨ���ģʽ
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;//����
  GPIO_Init(GPIOE, &GPIO_InitStructure);//��ʼ��
}

static void EXTIX_Init(void)
{
	NVIC_InitTypeDef   NVIC_InitStructure;
	EXTI_InitTypeDef   EXTI_InitStructure;
	
	
 
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);//ʹ��SYSCFGʱ��

	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE, EXTI_PinSource10);//PA0 ���ӵ��ж���0
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE, EXTI_PinSource11);//PA0 ���ӵ��ж���0
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE, EXTI_PinSource12);//PA0 ���ӵ��ж���0
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE, EXTI_PinSource13);//PE2 ���ӵ��ж���2
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE, EXTI_PinSource14);//PE3 ���ӵ��ж���3
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE, EXTI_PinSource15);//PE4 ���ӵ��ж���4
	
  /* ����EXTI_Line0 */
  EXTI_InitStructure.EXTI_Line = EXTI_Line10|EXTI_Line11|EXTI_Line12|EXTI_Line13|EXTI_Line14|EXTI_Line15;//LINE0
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;//�ж��¼�
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising; //�½��ش��� 
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;//ʹ��LINE0
  EXTI_Init(&EXTI_InitStructure);//����
	
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;//�ⲿ�ж�2
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x03;//��ռ���ȼ�3
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x02;//�����ȼ�2
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;//ʹ���ⲿ�ж�ͨ��
  NVIC_Init(&NVIC_InitStructure);//����
	
	EXTI_ClearITPendingBit(EXTI_Line10);
	EXTI_ClearITPendingBit(EXTI_Line11);
	EXTI_ClearITPendingBit(EXTI_Line12);
	EXTI_ClearITPendingBit(EXTI_Line13);
	EXTI_ClearITPendingBit(EXTI_Line14);
	EXTI_ClearITPendingBit(EXTI_Line15);
}

void KEY_Init(void)
{
	Key_GPIO_Init(); //������Ӧ��IO�ڳ�ʼ��
	EXTIX_Init();
}

void EXTI15_10_IRQHandler(void)
{
	num++;
	if(KEY1 == 1)
	{
		KEY1_Flag=1;
		KEY2_Flag=0;
		KEY3_Flag=0;
		KEY4_Flag=0;
		KEY5_Flag=0;
		KEY6_Flag=0;
	}
	if(KEY2 == 1)
	{
		KEY1_Flag=0;
		KEY2_Flag=1;
		KEY3_Flag=0;
		KEY4_Flag=0;
		KEY5_Flag=0;
		KEY6_Flag=0;
	}
	if(KEY3 == 1)
	{
		KEY1_Flag=0;
		KEY2_Flag=0;
		KEY3_Flag=1;
		KEY4_Flag=0;
		KEY5_Flag=0;
		KEY6_Flag=0;
	}
	if(KEY4 == 1)
	{
		KEY1_Flag=0;
		KEY2_Flag=0;
		KEY3_Flag=0;
		KEY4_Flag=1;
		KEY5_Flag=0;
		KEY6_Flag=0;
	}
	if(KEY5 == 1)
	{
		KEY1_Flag=0;
		KEY2_Flag=0;
		KEY3_Flag=0;
		KEY4_Flag=0;
		KEY5_Flag=1;
		KEY6_Flag=0;
	}
	if(KEY6 == 1)
	{
		KEY1_Flag=0;
		KEY2_Flag=0;
		KEY3_Flag=0;
		KEY4_Flag=0;
		KEY5_Flag=0;
		KEY6_Flag=1;
	}
	EXTI_ClearITPendingBit(EXTI_Line10);
	EXTI_ClearITPendingBit(EXTI_Line11);
	EXTI_ClearITPendingBit(EXTI_Line12);
	EXTI_ClearITPendingBit(EXTI_Line13);
	EXTI_ClearITPendingBit(EXTI_Line14);
	EXTI_ClearITPendingBit(EXTI_Line15);
}


