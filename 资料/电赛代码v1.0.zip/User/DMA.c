#include "DMA.h"
#include "GlobalVariable.h"
#include "arm_math.h"
#include "cd4066.h"
#include "key.h"

#define ADC1_DR_ADDRESS          ((uint32_t)0x4001204C)

void DMA2_Init(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;
  DMA_InitTypeDef       DMA_InitStructure;
  
 /* Enable ADC3, DMA and GPIO clocks ****************************************/ 
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);

	NVIC_InitStructure.NVIC_IRQChannel= DMA2_Stream0_IRQn;//TIM2_IRQn;  //
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;  
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);  
/* DMA2 Stream0 channel2 configuration **************************************/
  DMA_InitStructure.DMA_Channel = DMA_Channel_0;  
  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)ADC1_DR_ADDRESS;
	//   DMA_InitStructure.DMA_PeripheralBaseAddr = (u32)&ADC1->DR;//DMA��Ӧ���������ַ
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)ADC_fft_inputbuf;//��������ʾ�׵�ַ
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
  DMA_InitStructure.DMA_BufferSize = FFT_LENGTH;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;         
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
  DMA_Init(DMA2_Stream0, &DMA_InitStructure);
	DMA_ClearITPendingBit(DMA2_Stream0,DMA_IT_TCIF0);
	DMA_ITConfig(DMA2_Stream0,DMA_IT_TC, ENABLE);
	DMA_Cmd(DMA2_Stream0, ENABLE);
}





void DMA2_Stream0_IRQHandler(void)         // ʹ��DMA�жϲɼ����ݣ��������׶�ʧ����
{
  if(DMA_GetITStatus(DMA2_Stream0,DMA_IT_TCIF0)!=RESET)
	{	     
		if(ADC_OK_Flag==0)
		{
			ADC_OK_Flag = 1;
			memcpy(ADC_fft_inputbuf_BUFFER,ADC_fft_inputbuf,sizeof(ADC_fft_inputbuf));
		}
		DMA_ClearITPendingBit(DMA2_Stream0,DMA_IT_TCIF0);                    
  }
}

