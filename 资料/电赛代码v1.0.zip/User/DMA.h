#ifndef __DMA_H
#define	__DMA_H

#include "stm32f4xx.h"

void DMA2_Init(void);

#endif

