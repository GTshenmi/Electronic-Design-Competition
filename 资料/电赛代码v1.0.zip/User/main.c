#include "stm32f4xx.h"
#include "lcd.h"
#include "lcd_init.h"
#include "bsp_systick.h"
#include "ADC.h"
#include "usart_printf.h"
#include "timer.h"
#include "globalvariable.h"
#include "arm_math.h"
#include "arm_const_structs.h"
#include "stdio.h"
#include "key.h"
#include "CD4066.h"

float fft_hz[5];
float fft_Value[5];
int FFT=0;
float a=0;


void scan(u16 mode)
{
	int i=0;
	
	FFT=0;
	

	
	if(ADC_OK_Flag==1)
	{
		memset(fft_Value,0,sizeof(fft_Value));
		memset(fft_hz,0,sizeof(fft_hz));
		for(i=0;i<FFT_LENGTH;i++)
		{
			fft_inputbuf[2*i]=ADC_fft_inputbuf_BUFFER[i]/4096.0f*3.3;
			fft_inputbuf[2*i+1]=0;
		}

		arm_cfft_f32(&arm_cfft_sR_f32_len4096,fft_inputbuf,0,1);
		arm_cmplx_mag_f32(fft_inputbuf,fft_outputbuf,FFT_LENGTH);//��������������ģ�÷�ֵ 
			
		for(i=1;i<FFT_LENGTH-1;i++)
		{
			if(fft_outputbuf[i]>fft_outputbuf[i-1]&&fft_outputbuf[i]>fft_outputbuf[i+1])
			{
				if(fft_outputbuf[i]>50)
				{
					disFFT[FFT].num =i;
					disFFT[FFT++].value =fft_outputbuf[i];
				}
			}
		}
		for(i=0;i<FFT/2;i++)
		{
			if((float)(disFFT[i].num-1)*Sampling_Frequency/FFT_LENGTH>=5100)
			{
				break;
			}
			else
			{
				fft_hz[i]=(float)((disFFT[i].num)*Sampling_Frequency/FFT_LENGTH);
				fft_Value[i]=(disFFT[i].value + disFFT[FFT-1-i].value)/FFT_LENGTH*2;
				//printf("Value[%d]:%f\n\r",i,fft_Value[i]);
				//printf("fft_hz[%f]:%f\r\n",(float)((disFFT[i].num)*Sampling_Frequency/FFT_LENGTH),((disFFT[i].value+disFFT[FFT-1-i].value)/FFT_LENGTH*2));
			}
		}
		arm_sqrt_f32(fft_Value[1]*fft_Value[1]+fft_Value[2]*fft_Value[2]+fft_Value[3]*fft_Value[3]+fft_Value[4]*fft_Value[4],&a);
		
		
		THD[mode]=a/fft_Value[0];
		printf("THD[%d]:%f\n\r",mode,THD[mode]);
		ADC_OK_Flag=0;
	}
}


int main(void)
{
	int i=0;
	u16 scan_mode=6;
	delay_init();       //��ʱ������ʼ��
	LCD_Init();//LCD��ʼ��
	LCD_Fill(0,0,LCD_W,LCD_H,WHITE);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	usart_Init();
	CD4066_GPIO_Init();
	ADC_Configuration();
	DMA2_Init();
	TIM1_PWM_Init();
	KEY_Init();
	TIM3_Int_Init(19999,8399);
	
	LCD_ShowChinese(0,40,"����",RED,WHITE,16,0);
	LCD_ShowChinese(0,80,"����",RED,WHITE,16,0);
	LCD_ShowChinese(0,120,"�ײ�",RED,WHITE,16,0);
	LCD_ShowChinese(0,160,"˫��",RED,WHITE,16,0);
	LCD_ShowChinese(0,200,"��Խ",RED,WHITE,16,0);
	LCD_ShowChinese(35,10,"һ��",RED,WHITE,16,0);
	LCD_ShowChinese(80,10,"����",RED,WHITE,16,0);
	LCD_ShowChinese(125,10,"����",RED,WHITE,16,0);
	LCD_ShowChinese(170,10,"�Ĵ�",RED,WHITE,16,0);
	LCD_ShowChinese(215,10,"���",RED,WHITE,16,0);
	LCD_ShowString(260,10,"THD",RED,WHITE,16,0);
	LCD_ShowString(300,40,"%",RED,WHITE,16,0);
	LCD_ShowString(300,80,"%",RED,WHITE,16,0);
	LCD_ShowString(300,120,"%",RED,WHITE,16,0);
	LCD_ShowString(300,160,"%",RED,WHITE,16,0);
	LCD_ShowString(300,200,"%",RED,WHITE,16,0);
	while(1)
	{
		if(KEY1_Flag==1||mode==0)
		{
//			i++;
//			if(i>=5)
//			{
//				i=0;
				LCD_ShowFloatNum1(260,40,THD[0]*100.0f,4,RED,WHITE,16);
				LCD_ShowFloatNum1(35,40,fft_Value[0],4,RED,WHITE,16);
				LCD_ShowFloatNum1(80,40,fft_Value[1],4,RED,WHITE,16);
				LCD_ShowFloatNum1(125,40,fft_Value[2],4,RED,WHITE,16);
				LCD_ShowFloatNum1(170,40,fft_Value[3],4,RED,WHITE,16);
				LCD_ShowFloatNum1(215,40,fft_Value[4],4,RED,WHITE,16);
//			}
			Normal();
			scan(0);
		}
		else if(KEY2_Flag==1||mode==1)
		{
//			i++;
//			if(i>=5)
//			{
//				i=0;
				LCD_ShowFloatNum1(260,80,THD[1]*100.0f,4,RED,WHITE,16);
				LCD_ShowFloatNum1(35,80,fft_Value[0],4,RED,WHITE,16);
				LCD_ShowFloatNum1(80,80,fft_Value[1],4,RED,WHITE,16);
				LCD_ShowFloatNum1(125,80,fft_Value[2],4,RED,WHITE,16);
				LCD_ShowFloatNum1(170,80,fft_Value[3],4,RED,WHITE,16);
				LCD_ShowFloatNum1(215,80,fft_Value[4],4,RED,WHITE,16);
//			}
			Top();
			scan(1);
		}
		else if(KEY3_Flag==1||mode==2)
		{
//			i++;
//			if(i>=5)
//			{
//				i=0;
				LCD_ShowFloatNum1(260,120,THD[2]*100.0f,4,RED,WHITE,16);
				LCD_ShowFloatNum1(35,120,fft_Value[0],4,RED,WHITE,16);
				LCD_ShowFloatNum1(80,120,fft_Value[1],4,RED,WHITE,16);
				LCD_ShowFloatNum1(125,120,fft_Value[2],4,RED,WHITE,16);
				LCD_ShowFloatNum1(170,120,fft_Value[3],4,RED,WHITE,16);
				LCD_ShowFloatNum1(215,120,fft_Value[4],4,RED,WHITE,16);
//			}
			Bottom();
			scan(2);
		}
		else if(KEY4_Flag==1||mode==3)
		{
//			i++;
//			if(i>=5)
//			{
//				i=0;
				LCD_ShowFloatNum1(260,160,THD[3]*100.0f,4,RED,WHITE,16);
				LCD_ShowFloatNum1(35,160,fft_Value[0],4,RED,WHITE,16);
				LCD_ShowFloatNum1(80,160,fft_Value[1],4,RED,WHITE,16);
				LCD_ShowFloatNum1(125,160,fft_Value[2],4,RED,WHITE,16);
				LCD_ShowFloatNum1(170,160,fft_Value[3],4,RED,WHITE,16);
				LCD_ShowFloatNum1(215,160,fft_Value[4],4,RED,WHITE,16);
//			}
			Two_way();
			scan(3);
		}
		else if(KEY5_Flag==1||mode==4)
		{
			i++;
//			if(i>=5)
//			{
//				i=0;
				LCD_ShowFloatNum1(260,200,THD[4]*100.0f,4,RED,WHITE,16);
				LCD_ShowFloatNum1(35,200,fft_Value[0],4,RED,WHITE,16);
				LCD_ShowFloatNum1(80,200,fft_Value[1],4,RED,WHITE,16);
				LCD_ShowFloatNum1(125,200,fft_Value[2],4,RED,WHITE,16);
				LCD_ShowFloatNum1(170,200,fft_Value[3],4,RED,WHITE,16);
				LCD_ShowFloatNum1(215,200,fft_Value[4],4,RED,WHITE,16);
//			}
			Cross();
			scan(4);
		}
		if(KEY6_Flag==0)
		{
				mode=6;
		}
	}
}

