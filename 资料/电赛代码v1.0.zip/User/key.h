#ifndef __KEY_H
#define __KEY_H

#include "stm32f4xx.h"
#include "sys.h"

#define KEY1 PEin(10)
#define KEY2 PEin(11)
#define KEY3 PEin(12)
#define KEY4 PEin(13)
#define KEY5 PEin(14)
#define KEY6 PEin(15)


extern u8 KEY1_Flag;
extern u8 KEY2_Flag;
extern u8 KEY3_Flag;
extern u8 KEY4_Flag;
extern u8 KEY5_Flag;
extern u8 KEY6_Flag;

extern u16 num;

void KEY_Init(void);

#endif
