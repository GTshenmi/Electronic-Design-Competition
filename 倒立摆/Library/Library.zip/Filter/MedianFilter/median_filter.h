#ifndef _MEDIAN_FILTER_H_
#define _MEDIAN_FILTER_H_

#include "main.h" /*Delay�������ڵ�.h�ļ�*/

#define MedianFilterDelay(ms) HAL_Delay(ms)

#define CollectFunc() HAL_GetTick()

#define CollectFuncTypeDef unsigned int

float MedianFilter(float i,float j,float k);
float SlidingMedianFilter(float i[],float j[],float k[]);

float F_SlidingMedianFilter(CollectFuncTypeDef (*CollectFunc)(),unsigned int delay_time);
float F_MedianFilter(CollectFuncTypeDef (*CollectFunc)(),unsigned int delay_time);

#endif
