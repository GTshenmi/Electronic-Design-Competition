#ifndef __GLOBALVARIABLE_H
#define __GLOBALVARIABLE_H	 

#include <stm32f4xx.h>

typedef struct{
	u16 num;
	float value;
	float hz;
}disBuf;

#define Sampling_Frequency  32768

#define FFT_LENGTH        4096         //FFT���ȣ�Ĭ����1024��
extern disBuf disFFT[(FFT_LENGTH>>1)];   //Ƶ��������
extern disBuf max;
extern uint16_t ADC_fft_inputbuf[FFT_LENGTH];
extern float fft_inputbuf[FFT_LENGTH*2]; 	//FFT��������
extern float fft_outputbuf[FFT_LENGTH];    //FFT�������
extern float fft_outputbuf1[FFT_LENGTH];    //FFT�������
extern u8 ADC_OK_Flag;
extern uint16_t ADC_fft_inputbuf_BUFFER[FFT_LENGTH];
extern u16 mode;
extern float THD[5];


extern float display_Normal[6];
extern float display_Top[6];
extern float display_Bottom[6];
extern float display_Two_way[6];
extern float display_Cross[6];

extern u16 time_flag;

#endif

