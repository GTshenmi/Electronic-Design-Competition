# STM32-oscilloscope-with-FFT-

使用STM32的简单的示波器，使用STM32内部的ADC。
加上ST官方提供的DSP库进行FFT计算显示频谱和频率。
视频地址 https://www.bilibili.com/video/av40537526
