#include "stm32f4xx.h"
#include <stdio.h>

void STM32_GPIO_Init(void);
void usart_Init (void);
int fputc(int ch, FILE *f);
int fgetc(FILE *f);
